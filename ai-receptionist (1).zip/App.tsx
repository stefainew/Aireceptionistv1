
import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import ProblemSection from './components/ProblemSection';
import AudioDemo from './components/AudioDemo';
import ConversationDemo from './components/ConversationDemo';
import Features from './components/Features';
import ComparisonTable from './components/ComparisonTable';
import Testimonials from './components/Testimonials';
import FAQ from './components/FAQ';
import BookingSection from './components/BookingSection';
import Footer from './components/Footer';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-black text-white selection:bg-neon-500 selection:text-black overflow-x-hidden relative">
      {/* Ambient background effects with Image */}
      <div className="fixed inset-0 z-0 pointer-events-none">
        {/* Professional Background Image */}
        <div 
            className="absolute inset-0 bg-cover bg-center opacity-20"
            style={{ 
                backgroundImage: `url('https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=2072&auto=format&fit=crop')` 
            }}
        />
        {/* Gradient Overlay for legibility */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/90 to-black"></div>

        {/* Color Blobs */}
        <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-neon-500/10 rounded-full blur-[128px] -translate-y-1/2 mix-blend-screen"></div>
        <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] bg-blue-600/10 rounded-full blur-[128px] translate-y-1/2 mix-blend-screen"></div>
      </div>

      <div className="relative z-10 flex flex-col">
        <Navbar />
        <main className="flex-grow">
          <Hero />
          <ProblemSection />
          <AudioDemo />
          <ConversationDemo />
          <Features />
          <ComparisonTable />
          <Testimonials />
          <FAQ />
          <BookingSection />
        </main>
        <Footer />
      </div>
    </div>
  );
};

export default App;
