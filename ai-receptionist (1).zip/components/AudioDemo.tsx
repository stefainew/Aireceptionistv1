
import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, Activity, Volume2, AlertCircle } from 'lucide-react';

const AudioDemo: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [fileError, setFileError] = useState(false);

  // Hardcoded source for the production version
  // За да работи това, файлът трябва да се казва "demo.mp3" и да е в главната (public) директория.
  const audioSrc = '/demo.mp3';

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [bars, setBars] = useState<number[]>(new Array(32).fill(10));

  // Audio Element Management
  useEffect(() => {
    if (!audioRef.current) {
      audioRef.current = new Audio(audioSrc);
      audioRef.current.preload = "metadata";
    }

    const audio = audioRef.current;

    const updateTime = () => setCurrentTime(audio.currentTime);
    const updateDuration = () => {
        if(!isNaN(audio.duration) && audio.duration !== Infinity) {
            setDuration(audio.duration);
        }
    };
    const onEnd = () => {
      setIsPlaying(false);
      setCurrentTime(0);
      setBars(new Array(32).fill(10));
    };

    const onError = (e: Event) => {
        console.error("Audio Load Error:", e);
        setIsPlaying(false);
        setFileError(true);
    };

    audio.addEventListener('timeupdate', updateTime);
    audio.addEventListener('loadedmetadata', updateDuration);
    audio.addEventListener('ended', onEnd);
    audio.addEventListener('error', onError);

    return () => {
        audio.removeEventListener('timeupdate', updateTime);
        audio.removeEventListener('loadedmetadata', updateDuration);
        audio.removeEventListener('ended', onEnd);
        audio.removeEventListener('error', onError);
        audio.pause();
    };
  }, [audioSrc]);

  const togglePlay = async () => {
    if (fileError) return;
    
    const audio = audioRef.current;
    if (!audio) return;

    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
    } else {
      try {
        await audio.play();
        setIsPlaying(true);
      } catch (e) {
        console.error("Play failed", e);
        setIsPlaying(false);
      }
    }
  };

  // Visualizer Animation
  useEffect(() => {
    let interval: any;
    if (isPlaying) {
      interval = setInterval(() => {
        setBars((prev) =>
          prev.map((h) => {
             const target = Math.random() * 100;
             const move = (target - h) * 0.2; 
             return Math.max(10, h + move);
          })
        );
      }, 50);
    } else {
      setBars(new Array(32).fill(10));
    }
    return () => clearInterval(interval);
  }, [isPlaying]);

  // Helper to format time
  const formatTime = (time: number) => {
    if (isNaN(time)) return "00:00";
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes < 10 ? '0' : ''}${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
  };

  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <section id="demo" className="py-24 bg-dark-900 border-y border-white/5 relative overflow-hidden scroll-mt-32">
      <div className="max-w-5xl mx-auto px-6 relative z-10">
        
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold mb-6 tracking-tight">
            Запознайте се с <span className="text-neon-400">Анна</span>.
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg">
            Чуйте представянето на нашия виртуален асистент. Анна разбира контекст, интонация и е винаги на разположение.
          </p>
        </div>

        {/* Player Card */}
        <div className="bg-gradient-to-b from-dark-800 to-black border border-white/10 rounded-3xl p-8 md:p-12 shadow-2xl relative group">
            
            <div className="flex flex-col md:flex-row items-center gap-8 md:gap-12 relative z-10">
                
                {/* Play Button */}
                <button
                    onClick={togglePlay}
                    disabled={fileError}
                    className={`flex-shrink-0 w-20 h-20 md:w-24 md:h-24 rounded-full flex items-center justify-center transition-all duration-300 z-20 ${
                        fileError 
                            ? 'bg-red-500/10 text-red-500 border border-red-500/50 cursor-not-allowed' 
                            : 'bg-white text-black hover:scale-105 hover:shadow-[0_0_30px_rgba(255,255,255,0.4)] cursor-pointer'
                    }`}
                >
                    {fileError ? (
                         <Volume2 className="w-8 h-8" /> 
                    ) : isPlaying ? (
                        <Pause className="w-8 h-8 fill-current" />
                    ) : (
                        <Play className="w-8 h-8 fill-current ml-1" />
                    )}
                </button>

                {/* Controls Area */}
                <div className="flex-grow w-full">
                    <div className="flex items-center justify-between mb-2 text-xs font-mono text-neon-400">
                        <span className="flex items-center gap-2">
                            <Activity className="w-3 h-3" /> AI ГЛАСОВО ДЕМО
                        </span>
                        <span className={`flex items-center gap-2 ${fileError ? 'text-red-500' : ''}`}>
                             <Volume2 className="w-3 h-3" /> 
                             {fileError ? "ЛИПСВА ФАЙЛ: demo.mp3" : (isPlaying ? "ВЪЗПРОИЗВЕЖДАНЕ..." : "ГОТОВ ЗА СТАРТ")}
                        </span>
                    </div>
                    
                    {/* Visualizer */}
                    <div className="h-24 flex items-center justify-between gap-1 md:gap-1.5 mb-6">
                        {bars.map((height, index) => (
                            <div
                                key={index}
                                className={`w-1.5 md:w-2 rounded-full transition-all duration-200 ease-out ${
                                    fileError ? 'bg-red-500/20' : 'bg-neon-500'
                                }`}
                                style={{ 
                                    height: `${fileError ? 20 : height}%`,
                                    opacity: isPlaying ? 1 : 0.2,
                                    background: fileError ? '#7f1d1d' : (isPlaying ? `rgb(34, 211, 238)` : '#333')
                                }}
                            />
                        ))}
                    </div>

                    {/* Timeline */}
                    <div 
                      className={`w-full h-1 rounded-full overflow-hidden ${
                          fileError ? 'bg-gray-800 cursor-not-allowed' : 'bg-gray-800 cursor-pointer group/bar'
                        }`}
                      onClick={(e) => {
                        if(audioRef.current && duration > 0 && !fileError) {
                            const rect = e.currentTarget.getBoundingClientRect();
                            const x = e.clientX - rect.left;
                            const percentage = x / rect.width;
                            audioRef.current.currentTime = percentage * duration;
                            setCurrentTime(percentage * duration);
                        }
                      }}
                    >
                        <div 
                            className={`h-full transition-all duration-100 ease-linear ${fileError ? 'bg-red-500' : 'bg-neon-400 group-hover/bar:bg-neon-300'}`}
                            style={{ width: `${progress}%` }}
                        />
                    </div>
                    
                    <div className="flex justify-between mt-2 text-xs text-gray-500 font-mono">
                        <span>{formatTime(currentTime)}</span>
                        <span>{formatTime(duration)}</span>
                    </div>
                </div>
            </div>
            
            {/* Error Message for missing file */}
            {fileError && (
                <div className="mt-8 p-4 rounded-xl border border-red-500/20 bg-red-950/20 flex items-start gap-3 animate-in fade-in slide-in-from-top-2">
                    <AlertCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
                    <div className="text-sm text-red-200">
                        <p className="font-bold text-red-400 mb-1">Аудио файлът не е намерен.</p>
                        <p className="opacity-80">
                            Моля, качете файла с име <strong>demo.mp3</strong> в основната папка на сайта.
                        </p>
                    </div>
                </div>
            )}

            <div className="mt-8 pt-6 border-t border-white/5">
                <div className="flex flex-wrap gap-4 text-sm text-gray-400 justify-center md:justify-start">
                    {['Естествена реч', 'Моментален отговор', 'Български език'].map((tag) => (
                         <div key={tag} className="flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/5">
                            <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></div>
                            {tag}
                        </div>
                    ))}
                </div>
            </div>
        </div>
      </div>
    </section>
  );
};

export default AudioDemo;
