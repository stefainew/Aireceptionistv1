
import React, { useState } from 'react';
import { Send, CheckCircle, Loader2, Video, Eye, MessageCircleQuestion, Check } from 'lucide-react';

const BookingSection: React.FC = () => {
  const [formState, setFormState] = useState({
    name: '',
    phone: '',
    email: '',
    type: 'clinic'
  });
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate network delay for better UX
    setTimeout(() => {
        setIsSubmitting(false);
        setIsSubmitted(true);
        // Clear form
        setFormState({
            name: '',
            phone: '',
            email: '',
            type: 'clinic'
        });
    }, 1500);
  };

  return (
    <section id="booking" className="py-24 bg-dark-900 relative scroll-mt-32">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_left,_var(--tw-gradient-stops))] from-neon-900/20 via-black to-black pointer-events-none"></div>

      <div className="max-w-6xl mx-auto px-6 relative z-10">
        
        <div className="bg-black/40 backdrop-blur-xl border border-white/10 rounded-3xl overflow-hidden flex flex-col md:flex-row">
                
                {/* Left Info Side - How it Works */}
                <div className="md:w-5/12 bg-dark-800/80 p-8 md:p-10 flex flex-col relative border-r border-white/5">
                    
                    <h3 className="text-2xl font-bold text-white mb-8">Как работи демонстрацията</h3>
                    
                    <div className="space-y-8 relative mb-10">
                        {/* Connecting Line */}
                        <div className="absolute left-[19px] top-4 bottom-4 w-0.5 bg-white/10"></div>

                        {/* Step 1 */}
                        <div className="relative flex gap-4">
                            <div className="w-10 h-10 rounded-full bg-dark-900 border border-neon-500/50 flex items-center justify-center text-neon-400 font-bold z-10 shrink-0">
                                <Video className="w-5 h-5" />
                            </div>
                            <div>
                                <h4 className="text-white font-bold text-sm mb-1">15-минутна видео среща</h4>
                                <p className="text-gray-400 text-xs leading-relaxed">
                                    Срещаме се онлайн, за да разберем вашия бизнес и нужди.
                                </p>
                            </div>
                        </div>

                        {/* Step 2 */}
                        <div className="relative flex gap-4">
                            <div className="w-10 h-10 rounded-full bg-dark-900 border border-neon-500/50 flex items-center justify-center text-neon-400 font-bold z-10 shrink-0">
                                <Eye className="w-5 h-5" />
                            </div>
                            <div>
                                <h4 className="text-white font-bold text-sm mb-1">Виждате AI-то в действие</h4>
                                <p className="text-gray-400 text-xs leading-relaxed">
                                    Демонстрираме как AI рецепционистът обработва реални обаждания.
                                </p>
                            </div>
                        </div>

                        {/* Step 3 */}
                        <div className="relative flex gap-4">
                            <div className="w-10 h-10 rounded-full bg-dark-900 border border-neon-500/50 flex items-center justify-center text-neon-400 font-bold z-10 shrink-0">
                                <MessageCircleQuestion className="w-5 h-5" />
                            </div>
                            <div>
                                <h4 className="text-white font-bold text-sm mb-1">Отговаряме на въпросите ви</h4>
                                <p className="text-gray-400 text-xs leading-relaxed">
                                    Обсъждаме цени, интеграции и специфични за вашия бизнес сценарии.
                                </p>
                            </div>
                        </div>
                    </div>

                    {/* Badge */}
                    <div className="inline-flex items-center gap-2 bg-neon-500/10 text-neon-400 px-3 py-1.5 rounded text-xs font-bold uppercase tracking-wider mb-6 w-fit border border-neon-500/20">
                        Без ангажимент
                        <span className="block w-1.5 h-1.5 rounded-full bg-neon-400 animate-pulse"></span>
                    </div>
                    <p className="text-gray-500 text-xs italic mb-6">Добре сте дошли, дори само да проучвате възможностите.</p>

                    {/* What you will learn */}
                    <div className="mt-auto pt-6 border-t border-white/10">
                        <h5 className="text-white text-xs font-bold uppercase tracking-wider mb-4">Какво ще научите:</h5>
                        <ul className="space-y-2">
                            <li className="flex items-start gap-2 text-gray-400 text-xs">
                                <Check className="w-3 h-3 text-neon-500 mt-0.5 shrink-0" />
                                Как AI-то може да намали вашите разходи
                            </li>
                            <li className="flex items-start gap-2 text-gray-400 text-xs">
                                <Check className="w-3 h-3 text-neon-500 mt-0.5 shrink-0" />
                                Колко време отнема интеграцията
                            </li>
                            <li className="flex items-start gap-2 text-gray-400 text-xs">
                                <Check className="w-3 h-3 text-neon-500 mt-0.5 shrink-0" />
                                Как работи интеграцията с вашите системи
                            </li>
                            <li className="flex items-start gap-2 text-gray-400 text-xs">
                                <Check className="w-3 h-3 text-neon-500 mt-0.5 shrink-0" />
                                Реални примери от вашата индустрия
                            </li>
                        </ul>
                    </div>
                </div>

                {/* Right Form Side */}
                <div className="md:w-7/12 p-8 md:p-12 flex items-center bg-black/20">
                    {!isSubmitted ? (
                    <div className="w-full">
                        <div className="mb-8">
                             <h3 className="text-3xl font-bold text-white mb-2">Безплатна консултация</h3>
                             <p className="text-gray-400 text-sm">Попълнете формата и ние ще се свържем с вас.</p>
                        </div>

                        <form onSubmit={handleSubmit} className="space-y-6 w-full animate-in fade-in slide-in-from-bottom-4 duration-500">
                            <div>
                                <label className="block text-xs font-medium text-gray-500 uppercase tracking-wider mb-2">Вашето Име</label>
                                <input 
                                    type="text" 
                                    required
                                    className="w-full bg-dark-700 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-neon-500 focus:ring-1 focus:ring-neon-500 transition-all"
                                    placeholder="Иван Иванов"
                                    value={formState.name}
                                    onChange={(e) => setFormState({...formState, name: e.target.value})}
                                    disabled={isSubmitting}
                                />
                            </div>
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label className="block text-xs font-medium text-gray-500 uppercase tracking-wider mb-2">Телефон</label>
                                    <input 
                                        type="tel" 
                                        required
                                        className="w-full bg-dark-700 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-neon-500 focus:ring-1 focus:ring-neon-500 transition-all"
                                        placeholder="+359..."
                                        value={formState.phone}
                                        onChange={(e) => setFormState({...formState, phone: e.target.value})}
                                        disabled={isSubmitting}
                                    />
                                </div>
                                 <div>
                                    <label className="block text-xs font-medium text-gray-500 uppercase tracking-wider mb-2">Email</label>
                                    <input 
                                        type="email" 
                                        required
                                        className="w-full bg-dark-700 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-neon-500 focus:ring-1 focus:ring-neon-500 transition-all"
                                        placeholder="hello@company.com"
                                        value={formState.email}
                                        onChange={(e) => setFormState({...formState, email: e.target.value})}
                                        disabled={isSubmitting}
                                    />
                                </div>
                            </div>

                            <div>
                                <label className="block text-xs font-medium text-gray-500 uppercase tracking-wider mb-2">Тип Бизнес</label>
                                <select 
                                    className="w-full bg-dark-700 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-neon-500 focus:ring-1 focus:ring-neon-500 transition-all"
                                    value={formState.type}
                                    onChange={(e) => setFormState({...formState, type: e.target.value})}
                                    disabled={isSubmitting}
                                >
                                    <option value="clinic">Медицинска клиника / Стоматолог</option>
                                    <option value="lawyer">Адвокатска кантора</option>
                                    <option value="service">Услуги / Сервиз</option>
                                    <option value="realestate">Недвижими имоти</option>
                                    <option value="other">Друго</option>
                                </select>
                            </div>

                            <button 
                                type="submit"
                                disabled={isSubmitting}
                                className="w-full py-4 bg-white text-black font-bold rounded-lg hover:bg-gray-200 disabled:bg-gray-500 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2 mt-4 group"
                            >
                                {isSubmitting ? (
                                    <>
                                        <Loader2 className="w-4 h-4 animate-spin" />
                                        <span>Изпращане...</span>
                                    </>
                                ) : (
                                    <>
                                        <span>Изпрати заявка</span>
                                        <Send className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                                    </>
                                )}
                            </button>
                            <p className="text-center text-gray-600 text-xs mt-4">
                                Вашите данни са защитени и няма да бъдат споделяни с трети страни.
                            </p>
                        </form>
                    </div>
                    ) : (
                        <div className="w-full text-center animate-in zoom-in duration-500">
                            <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6 text-green-500 border border-green-500/30">
                                <CheckCircle className="w-10 h-10" />
                            </div>
                            <h4 className="text-2xl font-bold text-white mb-2">Успешно изпратено!</h4>
                            <p className="text-gray-400 mb-8 max-w-xs mx-auto">
                                Благодарим за интереса. Ще се свържем с вас възможно най-скоро за потвърждение на часа.
                            </p>
                            <button 
                                onClick={() => setIsSubmitted(false)}
                                className="text-sm text-gray-500 hover:text-white underline"
                            >
                                Върни се назад
                            </button>
                        </div>
                    )}
                </div>

        </div>

      </div>
    </section>
  );
};

export default BookingSection;
