
import React, { useState, useEffect } from 'react';
import { Cpu, Menu, X } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (e: React.MouseEvent, id: string) => {
    e.preventDefault();
    const section = document.getElementById(id);
    if (section) {
      section.scrollIntoView({ behavior: 'smooth' });
      setIsMobileMenuOpen(false);
    }
  };

  const navLinks = [
    { name: 'Демо', href: '#demo' },
    { name: 'Сравнение', href: '#comparison' },
    { name: 'Контакти', href: '#booking' },
  ];

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 border-b ${
        isScrolled
          ? 'bg-black/80 backdrop-blur-md border-white/10 py-4'
          : 'bg-transparent border-transparent py-6'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        <a 
          href="/"
          className="flex items-center gap-2 text-neon-400 font-bold text-xl tracking-tighter cursor-pointer hover:opacity-90 transition-opacity" 
          onClick={(e) => {
            e.preventDefault();
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
        >
          <div className="p-1.5 bg-neon-500/20 rounded-lg border border-neon-500/50">
            <Cpu className="w-6 h-6" />
          </div>
          <span className="text-white">AI</span> Receptionist
        </a>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              onClick={(e) => scrollToSection(e, link.href.replace('#', ''))}
              className="text-sm font-medium text-gray-400 hover:text-neon-400 transition-colors cursor-pointer"
            >
              {link.name}
            </a>
          ))}
          
          <div className="h-6 w-px bg-white/10 mx-2"></div>

          <button
            onClick={(e) => scrollToSection(e, 'booking')}
            className="px-4 py-2 text-sm font-semibold bg-white text-black rounded hover:bg-neon-400 transition-colors duration-300 cursor-pointer"
          >
            Запази час
          </button>
        </div>

        {/* Mobile Menu Toggle */}
        <button
          className="md:hidden text-white"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Nav */}
      {isMobileMenuOpen && (
        <div className="absolute top-full left-0 w-full bg-black border-b border-white/10 p-6 flex flex-col gap-4 md:hidden animate-in slide-in-from-top-5 shadow-2xl">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className="text-lg font-medium text-gray-300 hover:text-neon-400"
              onClick={(e) => scrollToSection(e, link.href.replace('#', ''))}
            >
              {link.name}
            </a>
          ))}
          <button
            onClick={(e) => scrollToSection(e, 'booking')}
            className="w-full text-center py-3 bg-neon-500 text-black font-bold rounded cursor-pointer"
          >
            Запази час
          </button>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
