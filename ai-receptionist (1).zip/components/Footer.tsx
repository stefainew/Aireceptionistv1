
import React from 'react';

const Footer: React.FC = () => {
  const handleDemoLink = (e: React.MouseEvent, name: string) => {
    e.preventDefault();
    alert(`Това е демо линк за страницата "${name}". В реална среда тук ще се зареди съответната информация.`);
  };

  return (
    <footer className="bg-black border-t border-white/10 py-12">
      <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-6">
        
        <div className="text-center md:text-left">
            <div className="text-xl font-bold text-white mb-2">AI Receptionist</div>
            <p className="text-gray-500 text-sm">© 2024 Всички права запазени.</p>
        </div>

        <div className="flex flex-wrap justify-center gap-6 md:gap-8">
            <a href="#" onClick={(e) => handleDemoLink(e, "Политика за поверителност")} className="text-gray-500 hover:text-white text-sm transition-colors">Политика за поверителност</a>
            <a href="#" onClick={(e) => handleDemoLink(e, "Общи условия")} className="text-gray-500 hover:text-white text-sm transition-colors">Общи условия</a>
        </div>

      </div>
    </footer>
  );
};

export default Footer;
