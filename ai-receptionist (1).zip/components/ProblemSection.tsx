import React from 'react';
import { PhoneMissed, Clock, DollarSign } from 'lucide-react';

const ProblemSection: React.FC = () => {
  return (
    <section className="py-24 bg-dark-900 border-b border-white/5 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Text Content - Now appears first on mobile (default order) */}
          <div>
            <h2 className="text-3xl md:text-5xl font-bold mb-8 leading-tight">
              Вашият бизнес <span className="text-red-500">губи пари</span>, докато спите.
            </h2>
            <p className="text-lg text-gray-400 mb-10 leading-relaxed border-l-2 border-red-500/50 pl-6">
              Статистиката е безпощадна: <span className="text-white font-bold">62% от обажданията</span> към малкия бизнес остават без отговор. Всяко пропуснато обаждане е клиент, който отива при конкуренцията.
            </p>
            
            <div className="space-y-8">
                <div className="flex gap-5 items-start group">
                    <div className="p-3 bg-red-500/10 rounded-xl text-red-500 group-hover:bg-red-500 group-hover:text-white transition-colors">
                        <PhoneMissed className="w-6 h-6" />
                    </div>
                    <div>
                        <h4 className="text-white font-bold text-lg mb-1">Пропуснати възможности</h4>
                        <p className="text-gray-500 text-sm leading-relaxed">Клиентите рядко оставят гласови съобщения. Те просто затварят и звънят на следващия резултат в Google.</p>
                    </div>
                </div>
                <div className="flex gap-5 items-start group">
                    <div className="p-3 bg-red-500/10 rounded-xl text-red-500 group-hover:bg-red-500 group-hover:text-white transition-colors">
                        <Clock className="w-6 h-6" />
                    </div>
                    <div>
                        <h4 className="text-white font-bold text-lg mb-1">Ограничено време</h4>
                        <p className="text-gray-500 text-sm leading-relaxed">Рецепционистът работи 8 часа. Вашите клиенти искат да запазят час вечер, през уикенда или рано сутрин.</p>
                    </div>
                </div>
                <div className="flex gap-5 items-start group">
                    <div className="p-3 bg-red-500/10 rounded-xl text-red-500 group-hover:bg-red-500 group-hover:text-white transition-colors">
                        <DollarSign className="w-6 h-6" />
                    </div>
                    <div>
                        <h4 className="text-white font-bold text-lg mb-1">Скрити разходи</h4>
                        <p className="text-gray-500 text-sm leading-relaxed">Заплата, осигуровки, болнични и обучение на персонал струват хиляди левове всеки месец.</p>
                    </div>
                </div>
            </div>
          </div>

          {/* Visual Content - Now appears second on mobile (default order) */}
          <div className="relative">
            {/* Glowing effect */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-red-500/10 blur-[100px] rounded-full pointer-events-none"></div>
            
            <div className="relative bg-black border border-white/10 rounded-2xl p-6 md:p-8 shadow-2xl">
                <div className="flex items-center justify-between border-b border-white/10 pb-4 mb-4">
                    <span className="text-gray-500 text-sm font-medium uppercase tracking-wider">Входящи повиквания (Вчера)</span>
                    <div className="flex items-center gap-2 bg-red-500/10 px-3 py-1 rounded text-red-500 text-xs font-bold border border-red-500/20">
                        <PhoneMissed className="w-3 h-3" /> 6 Пропуснати
                    </div>
                </div>
                <div className="space-y-3">
                    {[1,2,3,4,5].map((i) => (
                        <div key={i} className="flex items-center justify-between p-4 bg-dark-800/50 rounded-lg border border-white/5 hover:bg-dark-800 transition-colors">
                            <div className="flex items-center gap-4">
                                <div className="w-10 h-10 rounded-full bg-red-500/10 flex items-center justify-center text-red-500 shrink-0">
                                    <PhoneMissed className="w-5 h-5" />
                                </div>
                                <div className="flex flex-col">
                                    <span className="text-white text-sm font-mono font-medium">088 456 78{i}{i}</span>
                                    <span className="text-xs text-gray-500">18:3{i} • Извън работно време</span>
                                </div>
                            </div>
                            <span className="text-red-500 text-sm font-bold bg-red-500/5 px-2 py-1 rounded">-150 лв</span>
                        </div>
                    ))}
                </div>
                 <div className="mt-6 pt-4 border-t border-white/10 text-center">
                    <p className="text-gray-400 text-sm">Потенциална загуба за деня: <span className="text-white font-bold text-lg ml-2">~750 лв</span></p>
                </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProblemSection;