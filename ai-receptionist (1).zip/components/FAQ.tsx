import React, { useState } from 'react';
import { Plus, Minus } from 'lucide-react';

const faqs = [
    {
        q: "Звучи ли като робот?",
        a: "Не. Използваме най-новите модели за синтез на реч, които включват 'аха', паузи за дишане, промяна в интонацията и разбират контекст. Повечето клиенти (над 95%) не разбират, че разговарят с изкуствен интелект."
    },
    {
        q: "Какво става, ако AI не знае отговора?",
        a: "Системата е настроена интелигентно. Ако срещне въпрос, който не е в базата ѝ от знания, тя учтиво ще предложи да прехвърли обаждането към вас или да запише съобщение, което ще получите веднага като текст."
    },
    {
        q: "Мога ли да използвам собствения си глас?",
        a: "Абсолютно! Можем да клонираме вашия глас или гласа на ваш служител, за да звучи AI рецепционистът точно както искате. Това създава уникално и лично преживяване за вашите клиенти и изгражда доверие."
    },
    {
        q: "Трудно ли е внедряването?",
        a: "Отнема по-малко от 30 минути. Ние настройваме всичко вместо вас според вашите нужди. Вие просто активирате пренасочване на обажданията към номера, който ще ви предоставим."
    },
    {
        q: "Може ли да работи с моя календар?",
        a: "Да, интегрираме се директно с Google Calendar, Calendly, Microsoft Outlook и повечето популярни CRM системи. Когато AI запише час, той автоматично се появява във вашия график."
    },
    {
        q: "Има ли договор и скрити такси?",
        a: "Няма дългосрочни договори. Плащате месец за месец. Можете да се откажете по всяко време. Няма такси за инсталация или скрити плащания."
    }
];

const FAQ: React.FC = () => {
    const [openIndex, setOpenIndex] = useState<number | null>(0);

    return (
        <section className="py-24 bg-dark-900 border-t border-white/5">
            <div className="max-w-3xl mx-auto px-6">
                <div className="text-center mb-16">
                    <h2 className="text-3xl md:text-4xl font-bold mb-4">Често задавани въпроси</h2>
                    <p className="text-gray-400">Всичко, което трябва да знаете преди да започнете.</p>
                </div>
                
                <div className="space-y-4">
                    {faqs.map((faq, index) => (
                        <div key={index} className={`border transition-colors rounded-2xl overflow-hidden ${openIndex === index ? 'border-neon-500/50 bg-white/5' : 'border-white/10 bg-black'}`}>
                            <button 
                                className="w-full flex items-center justify-between p-6 text-left hover:bg-white/5 transition-colors focus:outline-none"
                                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                            >
                                <span className={`text-lg font-medium transition-colors ${openIndex === index ? 'text-white' : 'text-gray-300'}`}>
                                    {faq.q}
                                </span>
                                <div className={`p-1 rounded-full transition-all duration-300 ${openIndex === index ? 'bg-neon-500 text-black rotate-180' : 'bg-white/10 text-white'}`}>
                                    {openIndex === index ? <Minus className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                                </div>
                            </button>
                            <div 
                                className={`overflow-hidden transition-all duration-300 ease-in-out ${openIndex === index ? 'max-h-48 opacity-100' : 'max-h-0 opacity-0'}`}
                            >
                                <div className="p-6 pt-0 text-gray-400 leading-relaxed border-t border-white/5 mt-2">
                                    {faq.a}
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default FAQ;