import React from 'react';
import { Check, X, User, Cpu } from 'lucide-react';

const ComparisonTable: React.FC = () => {
  
  const scrollToSection = (e: React.MouseEvent, id: string) => {
    e.preventDefault();
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="comparison" className="py-24 bg-black scroll-mt-32">
      <div className="max-w-7xl mx-auto px-6">
        
        <div className="mb-16 text-center">
          <h2 className="text-3xl md:text-5xl font-bold mb-6 tracking-tight">
            Математиката е <span className="text-white">проста</span>.
          </h2>
          <p className="text-gray-400 text-lg">
            Спестете хиляди левове годишно, като преминете към автоматизирано решение.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            
            {/* Human Card */}
            <div className="p-8 rounded-3xl border border-white/10 bg-dark-800/50 text-gray-400 grayscale hover:grayscale-0 transition-all duration-500">
                <div className="flex items-center gap-4 mb-8 border-b border-white/5 pb-6">
                    <div className="w-12 h-12 bg-gray-700 rounded-full flex items-center justify-center text-white">
                        <User className="w-6 h-6" />
                    </div>
                    <div>
                        <h3 className="text-xl font-bold text-white">Традиционен Служител</h3>
                        <p className="text-sm">Ограничен капацитет</p>
                    </div>
                </div>

                <div className="space-y-6">
                    <div className="flex justify-between items-center">
                        <span>Заплата (средно)</span>
                        <span className="text-xl font-bold text-white">1,500 лв <span className="text-sm font-normal text-gray-500">/мес</span></span>
                    </div>
                    <div className="flex justify-between items-center">
                        <span>Работно време</span>
                        <span className="text-white">8 часа / 5 дни</span>
                    </div>
                    <div className="flex justify-between items-center">
                        <span>Осигуровки & Бонуси</span>
                        <span className="text-red-400">+30% разходи</span>
                    </div>
                     <div className="flex justify-between items-center">
                        <span>Болнични & Отпуски</span>
                        <span className="text-red-400">Платени</span>
                    </div>
                     <div className="flex justify-between items-center">
                        <span>Едновременни разговори</span>
                        <span className="text-red-400 flex items-center gap-2">
                             <X className="w-4 h-4" /> 1 (Моно)
                        </span>
                    </div>
                </div>
            </div>

            {/* AI Card */}
            <div className="relative p-8 rounded-3xl border border-neon-500/30 bg-gradient-to-b from-dark-800 to-black shadow-[0_0_40px_rgba(34,211,238,0.15)] transform md:scale-105 z-10">
                <div className="absolute top-0 right-0 bg-neon-500 text-black text-xs font-bold px-3 py-1 rounded-bl-xl rounded-tr-xl">
                    ПРЕПОРЪЧАНО
                </div>

                <div className="flex items-center gap-4 mb-8 border-b border-white/10 pb-6">
                    <div className="w-12 h-12 bg-neon-500 rounded-full flex items-center justify-center text-black shadow-lg shadow-neon-500/50">
                        <Cpu className="w-6 h-6" />
                    </div>
                    <div>
                        <h3 className="text-xl font-bold text-white">AI Receptionist</h3>
                        <p className="text-sm text-neon-400">Неограничен потенциал</p>
                    </div>
                </div>

                <div className="space-y-6 text-gray-300">
                    <div className="flex justify-between items-center">
                        <span>Месечна такса</span>
                        <span className="text-3xl font-bold text-white">79 лв <span className="text-sm font-normal text-gray-500">/мес</span></span>
                    </div>
                    <div className="flex justify-between items-center">
                        <span>Работно време</span>
                        <span className="text-neon-400 font-semibold flex items-center gap-2">
                            <Check className="w-4 h-4" /> 24/7/365
                        </span>
                    </div>
                    <div className="flex justify-between items-center">
                        <span>Осигуровки & Бонуси</span>
                        <span className="text-neon-400 font-semibold flex items-center gap-2">
                             <Check className="w-4 h-4" /> 0.00 лв
                        </span>
                    </div>
                     <div className="flex justify-between items-center">
                        <span>Болнични & Отпуски</span>
                         <span className="text-neon-400 font-semibold flex items-center gap-2">
                             <Check className="w-4 h-4" /> Никога
                        </span>
                    </div>
                     <div className="flex justify-between items-center">
                        <span>Едновременни разговори</span>
                        <span className="text-neon-400 font-semibold flex items-center gap-2">
                             <Check className="w-4 h-4" /> Неограничени
                        </span>
                    </div>
                </div>

                <div className="mt-8 pt-6 border-t border-white/10">
                    <a 
                        href="#booking" 
                        onClick={(e) => scrollToSection(e, 'booking')}
                        className="block w-full py-4 bg-neon-500 hover:bg-neon-400 text-black text-center font-bold rounded-xl transition-colors shadow-[0_0_15px_rgba(34,211,238,0.4)] cursor-pointer"
                    >
                        Изберете AI Решение
                    </a>
                </div>
            </div>

        </div>
      </div>
    </section>
  );
};

export default ComparisonTable;