import React from 'react';
import { Calendar, MessageSquare, Shield, Zap, Globe, Database } from 'lucide-react';

const features = [
  {
    icon: <Calendar className="w-6 h-6 text-neon-400" />,
    title: "Автоматичен Календар",
    description: "AI записва часове директно във вашия Google Calendar или Calendly, като избягва дублиране на часове."
  },
  {
    icon: <MessageSquare className="w-6 h-6 text-neon-400" />,
    title: "Smart SMS",
    description: "Получавате незабавен SMS или Email с резюме на всеки разговор, веднага щом приключи."
  },
  {
    icon: <Database className="w-6 h-6 text-neon-400" />,
    title: "CRM Интеграция",
    description: "Данните за клиента се попълват автоматично във вашата CRM система, без ръчно въвеждане."
  },
  {
    icon: <Globe className="w-6 h-6 text-neon-400" />,
    title: "Многоезичност",
    description: "Обслужвайте чуждестранни клиенти с перфектен английски, немски или испански език."
  },
  {
    icon: <Shield className="w-6 h-6 text-neon-400" />,
    title: "Спам Филтър",
    description: "Интелигентно разпознаване и блокиране на нежелани рекламни обаждания и ботове."
  },
  {
    icon: <Zap className="w-6 h-6 text-neon-400" />,
    title: "Бърза Настройка",
    description: "Не се изисква нов хардуер. Просто пренасочете обажданията си и системата работи веднага."
  }
];

const Features: React.FC = () => {
  return (
    <section className="py-24 bg-black relative overflow-hidden">
        {/* Background Grid */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#262626_1px,transparent_1px),linear-gradient(to_bottom,#262626_1px,transparent_1px)] bg-[size:32px_32px] opacity-20"></div>
        
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="text-center mb-20">
          <h2 className="text-3xl md:text-5xl font-bold mb-6">Повече от <span className="text-gray-500">телефонен секретар</span></h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Пълна автоматизация на вашата рецепция. Инструменти, които ви пестят часове административна работа всеки ден.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <div key={index} className="group p-8 rounded-2xl bg-dark-900 border border-white/10 hover:border-neon-500/50 transition-all duration-300 hover:shadow-[0_0_30px_rgba(6,182,212,0.1)] relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"></div>
              
              <div className="relative z-10">
                <div className="mb-6 p-3 bg-dark-800 rounded-xl w-fit border border-white/5 group-hover:border-neon-500/30 transition-colors">
                    {feature.icon}
                </div>
                <h3 className="text-xl font-bold text-white mb-3">{feature.title}</h3>
                <p className="text-gray-400 leading-relaxed text-sm">
                    {feature.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;