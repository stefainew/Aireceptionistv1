import React, { useState, useEffect } from 'react';
import { Cpu, CheckCircle, Clock, Zap, ShieldCheck, Phone, Mic, Volume2, PhoneOff, Signal } from 'lucide-react';

type Message = {
  role: 'user' | 'ai';
  text: string;
  intent?: string;
  data?: string;
};

const conversationSequence: Message[] = [
  { 
    role: 'user', 
    text: "Здравейте, искам да запазя час за д-р Иванов." 
  },
  { 
    role: 'ai', 
    text: "Здравейте! Разбира се. Д-р Иванов има свободен час този четвъртък в 14:30 или в петък сутринта в 09:15. Кое ви е по-удобно?",
    intent: "НАМЕРЕНИЕ: Запазване на час",
    data: "СУБЕКТ: Д-р Иванов"
  },
  { 
    role: 'user', 
    text: "Петък сутринта е добре. Колко струва прегледът?" 
  },
  { 
    role: 'ai', 
    text: "Чудесно, записах ви за петък, 09:15. Първичният преглед е 50 лв. Имате ли други въпроси?",
    intent: "ДЕЙСТВИЕ: Събитие в Календар",
    data: "ПОТВЪРДЕНО: Петък @ 09:15"
  },
  { 
    role: 'user', 
    text: "Не, това е всичко. Благодаря!" 
  },
  { 
    role: 'ai', 
    text: "Благодаря ви! Желая ви хубав ден.",
    intent: "СТАТУС: Разговорът приключи",
    data: "ЛОГ: SMS Изпратен"
  }
];

const ConversationDemo: React.FC = () => {
  const [step, setStep] = useState(0);
  const [isThinking, setIsThinking] = useState(false);
  const [callDuration, setCallDuration] = useState(0);

  // Timer for the "Phone Call"
  useEffect(() => {
    const timer = setInterval(() => {
        setCallDuration(prev => prev + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatDuration = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m < 10 ? '0' : ''}${m}:${s < 10 ? '0' : ''}${s}`;
  };

  useEffect(() => {
    let timeout: any;

    const runSequence = () => {
      if (step < conversationSequence.length) {
        // Simulate "Thinking" time before AI speaks
        const currentMessage = conversationSequence[step];
        const isAI = currentMessage.role === 'ai';
        
        if (isAI && !isThinking) {
            setIsThinking(true);
            timeout = setTimeout(() => {
                setIsThinking(false);
                // Show message
                setStep(s => s + 1);
            }, 800); // Thinking delay
        } else {
             // User message or AI finishing speaking
             timeout = setTimeout(() => {
                setStep(s => s + 1);
            }, isAI ? 2500 : 1500); // Reading time
        }
      } else {
        // Reset loop
        timeout = setTimeout(() => {
          setStep(0);
          setCallDuration(0);
        }, 3000);
      }
    };

    runSequence();
    return () => clearTimeout(timeout);
  }, [step, isThinking]);

  return (
    <section id="logic-demo" className="py-24 bg-dark-900 border-y border-white/5 relative overflow-hidden scroll-mt-32">
      <div className="max-w-6xl mx-auto px-6 relative z-10">
        
        <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-neon-500/10 border border-neon-500/20 mb-6 animate-fade-in-up">
                <Zap className="w-4 h-4 text-neon-400" />
                <span className="text-xs font-bold tracking-wide text-neon-400 uppercase">
                    Вижте логиката в действие
                </span>
            </div>
          <h2 className="text-3xl md:text-5xl font-bold mb-6 tracking-tight">
            Повече от запис. <br />
            <span className="text-white">Истински интелект.</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg">
            Вижте как Анна обработва естествен телефонен разговор в реално време.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Left: The Phone UI */}
            <div className="lg:col-span-7 bg-black border-4 border-dark-700 rounded-[2.5rem] overflow-hidden shadow-2xl h-[600px] flex flex-col relative ring-4 ring-black/50">
                
                {/* Phone Header (Status Bar) */}
                <div className="bg-dark-800 px-6 py-4 flex justify-between items-center border-b border-white/5">
                    <span className="text-xs font-medium text-gray-400">14:30</span>
                    <div className="flex items-center gap-2 text-white">
                        <Signal className="w-4 h-4" />
                        <div className="w-6 h-3 bg-green-500 rounded-[2px] relative">
                             <div className="absolute -right-1 top-0.5 h-2 w-0.5 bg-green-500 rounded-[1px]"></div>
                        </div>
                    </div>
                </div>

                {/* Caller Info Header */}
                <div className="bg-gradient-to-b from-dark-800 to-black p-6 flex flex-col items-center border-b border-white/5 relative">
                    <div className="w-16 h-16 rounded-full bg-gradient-to-br from-neon-500 to-blue-600 p-0.5 mb-3 relative">
                         <div className="absolute inset-0 rounded-full animate-ping bg-neon-500/30"></div>
                         <div className="w-full h-full bg-black rounded-full flex items-center justify-center relative z-10">
                             <Cpu className="w-8 h-8 text-neon-400" />
                         </div>
                    </div>
                    <h3 className="text-xl font-bold text-white">Анна (AI Асистент)</h3>
                    <div className="flex items-center gap-2 mt-1">
                        <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                        <span className="text-neon-400 text-sm font-mono">{formatDuration(callDuration)}</span>
                    </div>
                </div>

                {/* Transcript Area */}
                <div className="flex-grow p-6 space-y-6 overflow-y-auto bg-black scroll-smooth">
                    {conversationSequence.slice(0, step).map((msg, idx) => (
                        <div key={idx} className={`flex flex-col ${msg.role === 'ai' ? 'items-start' : 'items-end'} animate-in slide-in-from-bottom-2 duration-300`}>
                            <span className="text-[10px] text-gray-500 mb-1 px-1">
                                {msg.role === 'ai' ? '🤖 AI Глас' : '📞 Клиент'}
                            </span>
                            <div className={`max-w-[85%] p-4 rounded-2xl text-sm leading-relaxed relative ${
                                msg.role === 'ai' 
                                    ? 'bg-dark-800 text-gray-100 rounded-tl-none border border-white/10' 
                                    : 'bg-neon-600 text-white rounded-tr-none shadow-[0_0_15px_rgba(8,145,178,0.3)]'
                            }`}>
                                {msg.text}
                            </div>
                        </div>
                    ))}
                    
                    {isThinking && (
                        <div className="flex flex-col items-start animate-in fade-in">
                            <span className="text-[10px] text-neon-500 mb-1 px-1 animate-pulse">Обработка...</span>
                            <div className="bg-dark-800 text-gray-400 p-4 rounded-2xl rounded-tl-none border border-white/10 flex items-center gap-1">
                                <span className="w-1.5 h-1.5 bg-neon-400 rounded-full animate-bounce"></span>
                                <span className="w-1.5 h-1.5 bg-neon-400 rounded-full animate-bounce [animation-delay:0.2s]"></span>
                                <span className="w-1.5 h-1.5 bg-neon-400 rounded-full animate-bounce [animation-delay:0.4s]"></span>
                            </div>
                        </div>
                    )}
                </div>

                {/* Phone Controls (Visual) */}
                <div className="p-6 bg-dark-900/80 backdrop-blur flex justify-around items-center border-t border-white/5">
                    <div className="flex flex-col items-center gap-1 opacity-50">
                        <div className="w-12 h-12 rounded-full bg-dark-800 flex items-center justify-center text-white">
                             <Mic className="w-5 h-5" />
                        </div>
                        <span className="text-[10px] text-gray-400">Mute</span>
                    </div>
                     <div className="flex flex-col items-center gap-1">
                        <div className="w-16 h-16 rounded-full bg-red-500 flex items-center justify-center text-white shadow-lg shadow-red-500/30">
                             <PhoneOff className="w-8 h-8" />
                        </div>
                    </div>
                     <div className="flex flex-col items-center gap-1 opacity-50">
                        <div className="w-12 h-12 rounded-full bg-dark-800 flex items-center justify-center text-white">
                             <Volume2 className="w-5 h-5" />
                        </div>
                        <span className="text-[10px] text-gray-400">Speaker</span>
                    </div>
                </div>
            </div>

            {/* Right: The Logic/Benefits */}
            <div className="lg:col-span-5 space-y-4 h-full flex flex-col justify-center pt-8">
                
                {/* Dynamic Logic Card */}
                <div className="bg-dark-800/40 border border-white/10 rounded-2xl p-6 relative overflow-hidden min-h-[200px]">
                    <div className="absolute top-0 right-0 p-4 opacity-20">
                        <ShieldCheck className="w-24 h-24 text-neon-500" />
                    </div>
                    
                    <h3 className="text-gray-400 text-xs font-bold uppercase tracking-widest mb-4 flex items-center gap-2">
                        <Cpu className="w-4 h-4" />
                        AI Логически Поток
                    </h3>
                    
                    <div className="space-y-3 font-mono text-sm relative z-10">
                        {step > 0 ? (
                             conversationSequence.slice(0, step).filter(m => m.role === 'ai').slice(-1).map((msg, i) => (
                                <div key={i} className="animate-in slide-in-from-right duration-500 bg-black/50 p-3 rounded border-l-2 border-neon-500">
                                    <div className="flex items-center gap-2 mb-2 text-green-400 font-bold">
                                        <CheckCircle className="w-4 h-4" />
                                        <span>{msg.intent || "ОБРАБОТКА..."}</span>
                                    </div>
                                    <div className="pl-6 text-neon-300 text-xs opacity-90">
                                        {msg.data || "Анализ на контекста..."}
                                    </div>
                                </div>
                            ))
                        ) : (
                            <div className="flex items-center gap-2 text-gray-500 italic">
                                <div className="w-2 h-2 bg-yellow-500 rounded-full animate-pulse"></div>
                                В очакване на обаждане...
                            </div>
                        )}
                    </div>
                </div>

                {/* Static Benefits */}
                <div className="grid gap-4">
                    <div className="p-4 rounded-xl bg-white/5 border border-white/5 flex items-start gap-4 transition-colors hover:bg-white/10">
                        <div className="p-2 bg-blue-500/20 rounded-lg text-blue-400">
                            <Phone className="w-5 h-5" />
                        </div>
                        <div>
                            <h4 className="text-white font-bold text-sm">100% Естествен Глас</h4>
                            <p className="text-gray-500 text-xs mt-1">Клиентите не разбират, че говорят с машина.</p>
                        </div>
                    </div>
                    <div className="p-4 rounded-xl bg-white/5 border border-white/5 flex items-start gap-4 transition-colors hover:bg-white/10">
                        <div className="p-2 bg-purple-500/20 rounded-lg text-purple-400">
                            <Cpu className="w-5 h-5" />
                        </div>
                        <div>
                            <h4 className="text-white font-bold text-sm">Динамичен Контекст</h4>
                            <p className="text-gray-500 text-xs mt-1">Помни имена, дати и предишни разговори.</p>
                        </div>
                    </div>
                </div>

            </div>

        </div>
      </div>
    </section>
  );
};

export default ConversationDemo;