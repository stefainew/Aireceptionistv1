import React from 'react';
import { Star, Quote } from 'lucide-react';

const testimonials = [
    {
        name: "Д-р Иван Петров",
        role: "Дентална клиника 'ДентЕстет'",
        text: "Преди AI Receptionist губехме около 15% от пациентите, защото рецепционистката беше заета с пациент на място. Сега графикът се пълни автоматично, дори през нощта.",
        rating: 5
    },
    {
        name: "Адв. Мария Георгиева",
        role: "Кантора Георгиева и Партньори",
        text: "Клиентите са впечатлени, че могат да запазят час за консултация в неделя вечер. Системата звучи изключително професионално и се справя със сложни запитвания.",
        rating: 5
    },
    {
        name: "Стефан Николов",
        role: "Автосервиз 'Скорост'",
        text: "Най-добрата инвестиция за годината. Спестихме заплатата на един човек и увеличихме записаните часове с 30% още първия месец.",
        rating: 5
    }
];

const Testimonials: React.FC = () => {
    return (
        <section className="py-24 bg-gradient-to-b from-black to-dark-900 border-t border-white/5">
            <div className="max-w-7xl mx-auto px-6">
                <div className="text-center mb-16">
                    <h2 className="text-3xl md:text-5xl font-bold mb-6">Доверие от <span className="text-neon-400">бизнеса</span></h2>
                    <p className="text-gray-400 text-lg">Вижте какво казват собствениците на бизнес, които вече използват системата.</p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {testimonials.map((t, i) => (
                        <div key={i} className="p-8 rounded-3xl bg-white/5 border border-white/10 flex flex-col relative hover:bg-white/[0.07] transition-colors">
                            <Quote className="absolute top-8 right-8 w-8 h-8 text-white/10" />
                            
                            <div className="flex gap-1 text-neon-400 mb-6">
                                {[...Array(t.rating)].map((_, i) => <Star key={i} className="w-4 h-4 fill-current" />)}
                            </div>
                            <p className="text-gray-300 text-lg mb-8 leading-relaxed">"{t.text}"</p>
                            <div className="mt-auto flex items-center gap-4">
                                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-gray-700 to-gray-900 flex items-center justify-center text-white font-bold">
                                    {t.name.charAt(0)}
                                </div>
                                <div>
                                    <div className="text-white font-bold text-sm">{t.name}</div>
                                    <div className="text-neon-500 text-xs">{t.role}</div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default Testimonials;