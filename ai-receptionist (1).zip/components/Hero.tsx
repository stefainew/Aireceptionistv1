import React from 'react';
import { ArrowRight, PhoneCall, Sparkles } from 'lucide-react';

const Hero: React.FC = () => {
  
  const scrollToSection = (e: React.MouseEvent, id: string) => {
    e.preventDefault();
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative pt-32 pb-20 md:pt-48 md:pb-24 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 relative z-10 text-center">
        
        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 mb-8 animate-fade-in-up backdrop-blur-sm">
          <Sparkles className="w-4 h-4 text-neon-400" />
          <span className="text-xs font-medium tracking-wide text-gray-300 uppercase">
            AI Технология от ново поколение
          </span>
        </div>

        {/* Headline */}
        <h1 className="text-5xl md:text-7xl lg:text-8xl font-extrabold tracking-tighter mb-8 leading-[1.1]">
          <span className="bg-clip-text text-transparent bg-gradient-to-b from-white to-white/60">
            Спрете да губите
          </span>
          <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-neon-400 via-neon-200 to-white animate-pulse-slow">
             клиенти.
          </span>
        </h1>

        {/* Subheadline */}
        <p className="text-lg md:text-xl text-gray-400 max-w-2xl mx-auto mb-10 leading-relaxed">
          Интелигентен AI рецепционист, който поема обаждания, записва часове и отговаря на въпроси 24/7. 
          <span className="text-white font-medium"> Без болнични. Без почивки. Без пропуснати ползи.</span>
        </p>

        {/* CTAs */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-20">
          <a
            href="#booking"
            onClick={(e) => scrollToSection(e, 'booking')}
            className="group relative inline-flex items-center gap-2 px-8 py-4 bg-neon-500 text-black font-bold rounded-full text-lg transition-transform hover:scale-105 hover:shadow-[0_0_20px_rgba(34,211,238,0.6)] cursor-pointer"
          >
            <span>Започнете сега</span>
            <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" />
            <div className="absolute inset-0 rounded-full ring-2 ring-white/20 group-hover:ring-white/40" />
          </a>
          
          <a
            href="#demo"
            onClick={(e) => scrollToSection(e, 'demo')}
            className="inline-flex items-center gap-2 px-8 py-4 bg-white/5 hover:bg-white/10 text-white font-semibold rounded-full text-lg border border-white/10 transition-colors backdrop-blur-sm cursor-pointer"
          >
            <PhoneCall className="w-5 h-5 text-neon-400" />
            <span>Чуйте демо</span>
          </a>
        </div>
        
        {/* Trusted By Strip */}
        <div className="border-t border-white/5 pt-10">
            <p className="text-xs text-gray-500 uppercase tracking-widest mb-6 font-medium">Използвано от иновативни бизнеси</p>
            <div className="flex flex-wrap justify-center items-center gap-8 md:gap-16 opacity-50 grayscale hover:grayscale-0 transition-all duration-500">
                {/* Placeholder Logos - using text for simplicity but styled like logos */}
                <span className="text-xl font-bold font-serif text-white">LawFirst</span>
                <span className="text-xl font-bold tracking-tighter text-white">DENTAL<span className="text-neon-500">PRO</span></span>
                <span className="text-xl font-bold italic text-white">AutoFix</span>
                <span className="text-xl font-extrabold text-white tracking-widest">ESTATE</span>
            </div>
        </div>

      </div>
    </section>
  );
};

export default Hero;